public interface ChampionshipManager {
    void addF1Driver();
    void deleteF1Driver();
    void changeF1Driver();
    void displayF1DriverStats();
    void displayAllDriversStats();
    void addCompletedRace();
    void clearData();
}
