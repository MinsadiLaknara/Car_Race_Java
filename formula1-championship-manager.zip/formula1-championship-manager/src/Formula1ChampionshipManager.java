import java.io.*;
import java.text.ParseException;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Formula1ChampionshipManager implements ChampionshipManager {
    private final int number_of_drivers;

    public static ArrayList<Formula1Driver> f1Drivers; //Stores all driver data
    private final Scanner scanner;
    public ArrayList<Race> races= new ArrayList<>(); //Stores all race data

    public Formula1ChampionshipManager(int number_of_drivers) {

        this.number_of_drivers = number_of_drivers;
        f1Drivers = new ArrayList<>();
        scanner = new Scanner(System.in);
        displayMenu();
    }

    private void displayMenu() {
        //read both text files automatically once program started
        File driver_file = new File("F1-driver-data.txt");
        if(driver_file.exists()){
            readDriverData();
        }
        File race_file = new File("F1-race-data.txt");
        if(race_file.exists()){
            readRaceData();
        }

        while(true) {
            System.out.println("\nFormula 1 Championship Menu\n----------------------------");
            System.out.println("Enter '1' to add new driver");
            System.out.println("Enter '2' to delete an existing driver");
            System.out.println("Enter '3' to change the driver of an existing team (e.g. Change the driver for the 'Mercedes' team)");
            System.out.println("Enter '4' to see statistics and details of a specific driver");
            System.out.println("Enter '5' to see all driver standings");
            System.out.println("Enter '6' to add a completed race");
            System.out.println("Enter '7' to save all driver and race data in a file");
            System.out.println("Enter '8' to clear all data including drivers and races");
            System.out.println("Enter '9' to launch the GUI");
            String line = scanner.nextLine();
            int selection = 0;
            try {
                selection = Integer.parseInt(line);
            } catch (Exception e) {
            }

            switch(selection) {
                case 1 :
                    addF1Driver();
                    break;
                case 2 :
                    deleteF1Driver();
                    break;
                case 3 :
                    changeF1Driver();
                    break;
                case 4 :
                    displayF1DriverStats();
                    break;
                case 5 :
                    displayAllDriversStats();
                    break;
                case 6:
                    addCompletedRace();
                    break;
                case 7:
                    writeDriverData();
                    writeRaceData();
                    System.out.println("Data successfully saved!");
                    break;
                case 8:
                    clearData();
                    break;
                case 9:
                    f1GUI();
                    break;
                default:
                    System.out.println("Wrong input, Try Again!");
            }

        }
    }

    //taking drivers details as user input
    @Override
    public void addF1Driver(){
        if(f1Drivers.size() == number_of_drivers){
            System.out.println("Participation limit has been exceeded. Unable to add more drivers.");
            return;
        }

        Formula1Driver driver = new Formula1Driver();
        System.out.println("Enter the driver's name: ");
        String sc = scanner.nextLine();
        driver.setDriverName(sc);

        if(f1Drivers.contains(driver)){ //validation of drivers name
            System.out.println("Error : this driver is already exist in the 'F1 Championship'.");
            return;
        }

        System.out.println("Enter the driver's location: ");
        sc = scanner.nextLine();
        driver.setDriverLocation(sc);

        System.out.println("Enter the driver's team: ");
        sc = scanner.nextLine();
        driver.setDriverTeam(sc);

        //Adding driver details to 'f1Driver' array list
        f1Drivers.add(driver);

    }
    //delete a driver based on user preferences
    @Override
    public void deleteF1Driver() {
        System.out.println("List of available drivers\n--------------------------");
        System.out.printf("%-22s%-22s%n", "F1 Driver's Name", "Team"); //Printing all the drivers details for user's convenience (in columns)
        System.out.println(" ");

        for (Formula1Driver driver : f1Drivers) {
            System.out.printf("%-22s%-22s%n", driver.getDriverName(), driver.getDriverTeam()); //Printing all the drivers details for user's convenience (in columns)
        }
        System.out.println("\nEnter the driver's name that need to be deleted: ");
        String sc = scanner.nextLine();
        for(Formula1Driver driver : f1Drivers) {
            if(driver.getDriverName().equals(sc)){
                f1Drivers.remove(driver);
                System.out.println("Driver "+ driver.getDriverName()+" has been deleted from the 'F1 Championship'");
                return;
            }
        }
        System.out.println("Error : there is no such a driver exist in 'F1 Championship'.");
    }

    //change a driver of a team.
    @Override
    public void changeF1Driver() {
        System.out.println("Enter the team name of the driver that need to be replace");
        String name = scanner.nextLine();

        System.out.println("Enter the new driver's name: ");
        String name1 = scanner.nextLine();

        for(Formula1Driver driver: f1Drivers) {
            if(driver.getDriverName().equals(name1)){
                f1Drivers.remove(driver); //Remove the driver if it is exist
            }

            if(driver.getDriverTeam().equals(name)){
                driver.setDriverName(name1); //Assign a new driver
            }
        }
    }
    //Display stats of a driver
    @Override
    public void displayF1DriverStats() {

        System.out.println("Enter the driver's name: ");
        String sc = scanner.nextLine();
        for (Formula1Driver driver : f1Drivers) {
            if(driver.getDriverName().equals(sc)){
                System.out.println("\nDriver "+driver.getDriverName()+"'s Details and Statistics.\n");
                System.out.println("Name                         : "+driver.getDriverName());
                System.out.println("Team                         : "+driver.getDriverTeam());
                System.out.println("Location                     : "+driver.getDriverLocation());
                System.out.println("1st position count           : "+driver.getFirstPCount());
                System.out.println("2nd position count           : "+driver.getSecondPCount());
                System.out.println("3rd position count           : "+driver.getThirdPCount());
                System.out.println("Current total points         : "+driver.getTotalPoints());
                System.out.println("Number of races participated : "+driver.getRacesCompleted());
                return;
            }
        }
        System.out.println("Error : couldn't find that driver in 'F1 Championship' records.");
    }

    //Display stats table of all drivers
    @Override
    public void displayAllDriversStats() {
        Collections.sort(f1Drivers, new Sort());
        System.out.printf("%-22s%-22s%-22s%-22s%-22s%-22s%-22s%n", "F1 Driver's Name", "Team", "Location", "Total Points", "1st Positions", "2nd Positions", "3rd Position");
        System.out.printf("%-22s%-22s%-22s%-22s%-22s%-22s%-22s%n","--------------------","--------------------","--------------------","--------------------","--------------------","--------------------","--------------------");
        System.out.println(" ");

        for (Formula1Driver driver : f1Drivers) {
            System.out.printf("%-22s%-22s%-22s%-22s%-22s%-22s%-22s%n", driver.getDriverName(), driver.getDriverTeam(), driver.getDriverLocation(), driver.getTotalPoints(), driver.getFirstPCount(), driver.getSecondPCount(), driver.getThirdPCount());

        }
    }

    //Make a race. Automatically updates points and standings of all drivers.
    @Override
    public void addCompletedRace() {
        //Taking date as a user input
        System.out.println("Enter date :");
        System.out.println("[mm-dd-yyyy]");
        String d = scanner.nextLine();
        Date date;
        try {
            date = new SimpleDateFormat("MM-dd-yyyy").parse(d);
        } catch (ParseException ex) {
            System.out.println("You have to enter date in format mm-dd-yyyy");
            return;
        }

        System.out.println("\nList of drivers available to race\n----------------------------------"); //Printing all driver's details for user's ease
        System.out.printf("%-22s%-22s%n", "F1 Driver's Name", "Team");
        System.out.println(" ");

        for (Formula1Driver driver : f1Drivers) {
            System.out.printf("%-22s%-22s%n", driver.getDriverName(), driver.getDriverTeam()); //Printing all driver's details for user's ease
        }

        System.out.println("\nEnter 1st position: ");
        String input1 = scanner.nextLine();
        Formula1Driver d1 = null;

        for(Formula1Driver driver : f1Drivers) { //adding t.points, races completed, 1st place counts
            if (driver.getDriverName().equals(input1)) {
                driver.setTotalPoints(driver.getTotalPoints() + 25);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                driver.setFirstPCount(driver.getFirstPCount() + 1);
                System.out.println(driver.getTotalPoints());
                d1 = driver;
            }
        }
        if(d1 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }


        System.out.println("Enter 2nd position: ");
        String input2 = scanner.nextLine();
        Formula1Driver d2 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed, 2nd place counts
            if (driver.getDriverName().equals(input2)) {
                driver.setTotalPoints(driver.getTotalPoints() + 18);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                driver.setSecondPCount(driver.getSecondPCount() + 1);
                System.out.println(driver.getTotalPoints());
                d2 = driver;
            }
        }
        if(d2 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }


        System.out.println("Enter 3rd position: ");
        String input3 = scanner.nextLine();
        Formula1Driver d3 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed, 3rd place counts
            if (driver.getDriverName().equals(input3)) {
                driver.setTotalPoints(driver.getTotalPoints() + 15);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                driver.setThirdPCount(driver.getFirstPCount() + 1);
                System.out.println(driver.getTotalPoints());
                d3 = driver;
            }
        }
        if(d3 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }


        System.out.println("Enter 4th position: ");
        String input4 = scanner.nextLine();
        Formula1Driver d4 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed
            if (driver.getDriverName().equals(input4)) {
                driver.setTotalPoints(driver.getTotalPoints() + 12);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                System.out.println(driver.getTotalPoints());
                d4 = driver;
            }
        }
        if(d4 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }


        System.out.println("Enter 5th position: ");
        String input5 = scanner.nextLine();
        Formula1Driver d5 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed
            if (driver.getDriverName().equals(input5)) {
                driver.setTotalPoints(driver.getTotalPoints() + 10);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                System.out.println(driver.getTotalPoints());
                d5 = driver;
            }
        }
        if(d5 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }


        System.out.println("Enter 6th position: ");
        String input6 = scanner.nextLine();
        Formula1Driver d6 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed
            if (driver.getDriverName().equals(input6)) {
                driver.setTotalPoints(driver.getTotalPoints() + 8);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                System.out.println(driver.getTotalPoints());
                d6 = driver;
            }
        }
        if(d6 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }


        System.out.println("Enter 7th position: ");
        String input7 = scanner.nextLine();
        Formula1Driver d7 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed
            if (driver.getDriverName().equals(input7)) {
                driver.setTotalPoints(driver.getTotalPoints() + 6);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                System.out.println(driver.getTotalPoints());
                d7 = driver;
            }
        }
        if(d7 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }


        System.out.println("Enter 8th position: ");
        String input8 = scanner.nextLine();
        Formula1Driver d8 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed
            if (driver.getDriverName().equals(input8)) {
                driver.setTotalPoints(driver.getTotalPoints() + 4);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                System.out.println(driver.getTotalPoints());
                d8 = driver;
            }
        }
        if(d8 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }


        System.out.println("Enter 9th position: ");
        String input9 = scanner.nextLine();
        Formula1Driver d9 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed
            if (driver.getDriverName().equals(input9)) {
                driver.setTotalPoints(driver.getTotalPoints() + 2);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                System.out.println(driver.getTotalPoints());
                d9 = driver;
            }
        }
        if(d9 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }

        System.out.println("Enter 10th position: ");
        String input10 = scanner.nextLine();
        Formula1Driver d10 = null;

        for(Formula1Driver driver : f1Drivers) { //adding points to t.points, races completed
            if (driver.getDriverName().equals(input10)) {
                driver.setTotalPoints(driver.getTotalPoints() + 1);
                driver.setRacesCompleted(driver.getRacesCompleted() + 1);
                System.out.println(driver.getTotalPoints());
                d10 = driver;
            }
        }
        if(d10 == null) {
            System.out.println("Error : there is no such a driver exists in 'F1 Championship'.");
            return;
        }

        Race race = new Race ();
        race.setTenthRPosition(input10);
        race.setNinthRPosition(input9);
        race.setEighthRPosition(input8);
        race.setSeventhRPosition(input7);
        race.setSixthRPosition(input6);
        race.setFifthRPosition(input5);
        race.setFourthRPosition(input4);
        race.setThirdRPosition(input3);
        race.setSecondRPosition(input2);
        race.setFirstRPosition(input1);
        races.add(race);

        System.out.println();
    }

    //write driver data to a text file
    private void writeDriverData(){
        try{
            FileOutputStream writeDData = new FileOutputStream("F1-driver-data.txt");
            ObjectOutputStream writerD = new ObjectOutputStream(writeDData);

            writerD.writeObject(f1Drivers);
            writerD.flush();
            writerD.close();


        }catch (IOException e){
            e.printStackTrace();
        }
    }

    //write race data to a text file
    private void writeRaceData() {
        try {
            FileOutputStream writeRData = new FileOutputStream("F1-race-data.txt");
            ObjectOutputStream writerR = new ObjectOutputStream(writeRData);

            writerR.writeObject(races);
            writerR.flush();
            writerR.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    //read driver data from the text file when program starts and store in array
    private void readDriverData(){
        try {
            FileInputStream readDData = new FileInputStream("F1-driver-data.txt");
            ObjectInputStream readerD = new ObjectInputStream(readDData);

            ArrayList<Formula1Driver> read_F1Drivers = (ArrayList<Formula1Driver>) readerD.readObject();
            readerD.close();
            f1Drivers = read_F1Drivers;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //read race data from the text file when program starts and store in array
    private void readRaceData(){
        try{
            FileInputStream readRData = new FileInputStream("F1-race-data.txt");
            ObjectInputStream readerR = new ObjectInputStream(readRData);

            ArrayList<Race> read_races = (ArrayList<Race>) readerR.readObject();
            readerR.close();
            races = read_races;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void clearData(){
        f1Drivers.clear();
        races.clear();
        System.out.println("Cleared all data!\n");
        System.out.println("Alert : If you don't want the deleted data to be restored when you run the program again, Save! (Enter 7).");
    }

    private void f1GUI(){
        GUIF1.main(null);
    }
}

/*public static arrayList<Formula1Driver> driverrs(){f1Driver}
    public static arrayList<Formula1Driver> racess(){race}*/