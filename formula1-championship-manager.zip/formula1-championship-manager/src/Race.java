import java.io.Serializable;

public class Race implements Serializable {
    private String firstRPosition;
    private String secondRPosition;
    private String thirdRPosition;
    private String fourthRPosition;
    private String fifthRPosition;
    private String sixthRPosition;
    private String seventhRPosition;
    private String eighthRPosition;
    private String ninthRPosition;
    private String tenthRPosition;

    public String getFirstRPosition() {
        return firstRPosition;
    }

    public void setFirstRPosition(String firstRPosition) {
        this.firstRPosition = firstRPosition;
    }

    public String getSecondRPosition() {
        return secondRPosition;
    }

    public void setSecondRPosition(String secondRPosition) { this.secondRPosition = secondRPosition; }

    public String getThirdRPosition() {
        return thirdRPosition;
    }

    public void setThirdRPosition(String thirdRPosition) {
        this.thirdRPosition = thirdRPosition;
    }

    public String getFourthRPosition() {
        return fourthRPosition;
    }

    public void setFourthRPosition(String fourthRPosition) { this.fourthRPosition = fourthRPosition; }

    public String getFifthRPosition() {
        return fifthRPosition;
    }

    public void setFifthRPosition(String fifthRPosition) {
        this.fifthRPosition = fifthRPosition;
    }

    public String getSixthRPosition() {
        return sixthRPosition;
    }

    public void setSixthRPosition(String sixthRPosition) {
        this.sixthRPosition = sixthRPosition;
    }

    public String getSeventhRPosition() {
        return seventhRPosition;
    }

    public void setSeventhRPosition(String seventhRPosition) {
        this.seventhRPosition = seventhRPosition;
    }

    public String getEighthRPosition() {
        return eighthRPosition;
    }

    public void setEighthRPosition(String eighthRPosition) { this.eighthRPosition = eighthRPosition; }

    public String getNinthRPosition() {
        return ninthRPosition;
    }

    public void setNinthRPosition(String ninthRPosition) {
        this.ninthRPosition = ninthRPosition;
    }

    public String getTenthRPosition() {
        return tenthRPosition;
    }

    public void setTenthRPosition(String tenthRPosition) {
        this.tenthRPosition = tenthRPosition;
    }
}
