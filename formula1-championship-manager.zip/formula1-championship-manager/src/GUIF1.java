import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;

public class GUIF1 extends JFrame{


    //Java swing components
    JTable driverStatTableView;
    JScrollPane sPanel1;
    JButton ascendingOrderButton;
    JButton descendingByWinsButton;
    JButton createRaceButton;
    JLabel dateOfRace;
    JLabel raceDateWithProb;
    JTable randomRaceTable;
    JScrollPane sPanel2;
    JButton viewAllRaces;
    JButton search;
    JTextField inputName;
    JTable racesTable;
    JScrollPane sPanel3;
    JTable results;
    JScrollPane sPanel4;


    //Constructor
    public F1GUI(Formula1ChampionshipManager f) {

        setTitle("F1 Championship Manager"); //Title

        //Driver standings table
        String [] columnStatTable = {"F1 Driver's Name", "Team", "Location", "Total Points", "Races Participated", "1st Positions", "2nd Positions", "3rd Position"};
        String [][] rowsStatTable = new String[f.getDrivers().size()][8]; //Holds data of the table
        guiTableDataPointsDescending(rowsStatTable, f);
        driverStatTableView = new JTable (rowsStatTable,columnStatTable);
        driverStatTableView.setDefaultEditor(Object.class, null); //Get an uneditable table
        sPanel1 = new JScrollPane(driverStatTableView); //Make the table scrollable
        sPanel1.setBounds(25,25,750,300);

        //Button to sort driver standings table in ascending order
        ascendingOrderButton = new JButton("Ascending Order");
        ascendingOrderButton.setBounds(175,360,200,50);
        ascendingOrderButton.addActionListener(new ActionListener() { //Functionality
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                guiTableDataPointsAscending(rowsStatTable, f);
                driverStatTableView.repaint(); //Refresh the table
            }
        });

        //Button to sort ascending order table in descending order regarding number of first position won
        descendingByWinsButton = new JButton("Sort By Wins");
        descendingByWinsButton.setBounds(385,360,200,50);
        descendingByWinsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                guiTableDataPointsDescending(rowsStatTable,f);
                driverStatTableView.repaint(); //Refresh the table
            }
        });

        //Generates a random race with proof table
        String [] columnGeneratedRandom ={"Driver Name","Position"};
        String [][] randomRaceRow = new String[f.getDrivers().size()][8];
        dateOfRace = new JLabel();
        createRaceButton = new JButton("Random Race");
        createRaceButton.setBounds(175,420,200,50);
        createRaceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String date = randomRace(f, randomRaceRow);
                dateOfRace.setBounds(175,480,250,20);
                dateOfRace.setText("Date : " + date);
                guiTableDataPointsDescending(rowsStatTable,f); //Update values inside the table
                driverStatTableView.repaint(); //Refresh the table
                randomRaceTable = new JTable(randomRaceRow,columnGeneratedRandom);
                randomRaceTable.setDefaultEditor(Object.class, null);
                sPanel2 = new JScrollPane(randomRaceTable);
                sPanel2.setBounds(165,500,210,100);
                add(sPanel2);
            }
        });

        //Generates a random race according to probability with proof table
        createRaceButtonWithProb = new JButton("Probability Random Race");
        createRaceButtonWithProb.setBounds(385,420,200,50);
        //adds functionality to the button
        createRaceButtonWithProb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent){
                String date = randomRaceWithProbablitiy(f);
                guiTableDataPointsDescendings(rowsStatTable, f);
                driverStatTableView.repaint(); //refresh the table
            }
        });

        //Display all the finished races
        viewAllRaces = new JButton("View Races");
        viewAllRaces.setBounds(175,620,200,50);
        viewAllRaces.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] raceTableColumn = {"Date","Participant Count"};
                String[][] raceTableData = new String[f.getDrivers().size()][2];
                raceTableData(f,raceTableData);
                racesTable.setDefaultEditor(Object.class, null);
                sPanel3 = new JScrollPane(racesTable);
                sPanel3.setBounds(800, 25, 250, 400);
                add(sPanel3);
            }
        });


        //Display search results
        inputName = new JTextField(); //Gets search name
        inputName.setBounds(385,680,200,50);
        search = new JButton("Search");
        search.setBounds(175, 680, 200, 50);
        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String [] resultTableColumn = {"Date", "Finished Position"};
                String [][]resultTableData = new String[f.getDrivers().size()][2];
                resultTableData(inputName.getText(),f,resultTableData);
                results = new JTable(resultTableData,resultTableColumn);
                results.setDefaultEditor(Object.class, null);
                sPanel4 = new JScrollPane(results);
                sPanel4.setBounds(800,450,350,300);
                add(sPanel4);
            }
        });

        //Adds swing components to the interface
        add(sPanel1);
        add(ascendingOrderButton);
        add(createRaceButton);
        add(createRaceButtonWithProb);
        add(descendingByWinsButton);
        add(dateOfRace);
        add(viewAllRaces);
        add(inputName);
        add(search);
        setSize(1175,820);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //progress ends after pressing close button of the GUI
    }

    public void guiTableDataPointsDescending(String[][] rows,Formula1ChampionshipManager f){
        //Sort drivers in the "driverList" in descending order
        Collections.sort(f.getDrivers(), new PointComparatorascending());
        int i = 0;
        for (Formula1Driver temp : f.getDrivers()){
            rows [i][0]=temp.getName();
            rows [i][1]=temp.getTeam();
            rows [i][2]=temp.getLocation();
            rows [i][3]=Integer.toString(temp.getFirstposition());
            rows [i][3]=Integer.toString(temp.getSecondposition());
            rows [i][3]=Integer.toString(temp.getThirdposition());
            rows [i][3]=Integer.toString(temp.getNumberofracesparticipated());
            rows [i][3]=Integer.toString(temp.getNumberofpoints());
            i++;
        }
    }

    public void guiTableDataPointsAscending(String[][] rows, Formula1ChampionshipManager f) {
        //Sort drivers in the "driveList" in ascending order
        Collections.sort(f.getDrivers(), new PointComparatorascending());
        int i=0;
        for (Formula1Driver temp: f.getDriver()){
            rows [i][0] = temp.getName();
            rows [i][1] = temp.getTeam();
            rows [i][2] = temp.getLocation();
            rows [i][3] = Integer.toString(temp.getFirstposition());
            rows [i][4] = Integer.toString(temp.getSecondposition());
            rows [i][5] = Integer.toString(temp.getThirdposition());
            rows [i][6] = Integer.toString(temp.getNumberofracesparticipated());
            rows [i][7] = Integer.toString(temp.getNumberofpoints());
            i++;
        }
    }

    public void guiTableDataWinsDescending(String[][] rows, Formula1ChampionshipManager f){
        //Sort driver in the "driverList" in descending order considering wins
        Collections.sort(f.getDriver(), new PointComparator());
        int i=0;
        for (Formula1Driver temp: x.getDriver()){
            rows [i][0] = temp.getName();
            rows [i][1] = temp.getTeam();
            rows [i][2] = temp.getLocation();
            rows [i][3] = Integer.toString(temp.getFirstposition());
            rows [i][4] = Integer.toString(temp.getSecondposition());
            rows [i][5] = Integer.toString(temp.getThirdposition());
            rows [i][6] = Integer.toString(temp.getNumberofracesparticipated());
            rows [i][7] = Integer.toString(temp.getNumberofpoints());
            i++;
        }
    }


    public String randomRace(Formula1ChampionshipManager x,String[][] randomRaceRow){
        try{
            ArrayList<Integer> validPosition = new ArrayList<>(); //Store generated valid position
            int position;
            int i = 0;
            int month = (int) (Math.random()*12)+1; //Generates a random month
            Calender calender = Calender.getInstance();
            calender.set( 2021, month, 0);
            int dayOfMonth = calender.get(Calender.DAY_OF_MONTH);
            int day =(int)(Math.random()*dayOfMonth+1);
            String dateS = day + "/" + month + "/" +2021;
            SimpleDateFormate dateFormat = new SimpleDateFormate("dd/mm/yyy");
            Date date = dateFormat.parse(dateS);
            Race race = new Race(date, x.getDrivers());
            x.getRaces().add(race);

            for(FormulaDriver temp :x.getDrivers()) {
                while(true){
                    position = (int) (Math.random()*x.getDrivers().size())+1;
                    if (validPosition.isEmpty()){
                        validPosition.add(position);
                        break;
                    }else if(!validPosition.contains(position)){
                        validPosition.add(position);
                        break;
                    }
                }
                randomRaceRow[j][0] = temp.getName();
                randomRaceRow[j][1] = Integer.toString(position);
                //add points and position
                if(position == 1){
                    temp.setFirstposition();
                }else if (position == 2){
                    temp.setSecondposition();
                }else if (position == 3){
                    temp.setThridposition
                }
                race.setParticipatingDrivers();
                temp.setNumberofracepartipated();
                race.setDriverDetails(temp.getName(),Integer.toString(position));

                i++;;

            }
            return dateS;
        }catch (ParseException ignored){
            return null;
        }
    }

    public String randomRaceWithProbability(Formula1ChampionshipManager x){
        try{
            ArrayList<Integer> validPositionProb = new ArrayList<>();
            boolean won;
            int positionOfDriver;
            int randomNum;
            boolean gotFirstPosition = false;

            int month = (int) (Math.random() * 12) + 1;
            Calender calender = Calender.getInstance();
            calender.set(2021,month,0);
            int dayOfMonth = calender.get(Calender.DAY_OF_MONTH);
            int day = (int)(Math.random() *dayOfMonth +1);
            String dateS = day+ "/"+ month+"/"+2021;
            SimpleDateFormate dateFormat = new SimpleDateFormate("dd/mm/yyy");
            Race race = new Race(date, x.getDrivers());
            x.getRaces().add(race);
            collections.shuffle(x.getRaces());
            for (FormulaDriver temp : x.getDrivers()){
                int starting = x.getDrivers().indexOf(temp)+1;
                while(true){
                    randomNum = (int) (Math.random()*100 +1);
                    won = false;
                    if (starting == 1){
                        if(randomNum >=1 && randomNum <= 40){
                            won = true;
                        }
                    }else if (starting == 2){
                        if(randomNum >=40 && randomNum <= 70){
                            won = true;
                        }
                    }else if (starting == 3 || starting ==4){
                        if(randomNum >=70 && randomNum <= 80){
                            won = true;
                        }
                    }else if (starting >= 5 && starting <=8){
                        if(randomNum ==100 || randomNum == 99){
                            won = true;
                        }
                    }else if (starting == 9){
                        won = true;
                    }
                    if (won && !gotFirstPosition || (x.getDrivers().size() < 9 && starting == x.getDrivers().size-1 && !validPositionProb.contains(1))){
                        positionOfDriver = 1;
                        gotFirstPosition = true;
                    }else{
                        positionOfDriver = (int) (Math.random() * x.getDrivers().size() - 1) +2;
                    }
                    if (validPositionProb.isEmpty()){
                        validPositionProb.add(positionOfDriver);
                        break;
                    }else if (validPositionProb.contains(positionOfDriver)){
                        validPositionProb.add(positionOfDriver);
                        break;
                    }
                }
                temp.calcpoints(positionOfDriver);
                //add points and position
                if(positionOfDriver == 1){
                    temp.setFirstposition();
                }else if (positionOfDriver == 2){
                    temp.setSecondposition();
                }else if (positionOfDriver == 3){
                    temp.setThridposition();
                }
                race.setParticipatingDrivers();
                temp.setNumberofracepartipated();
                //Store name and position of each player
                race.setDriverDetails(temp.getName(),Integer.toString(positionOfDriver));

            }
            return dateS;
        }catch(ParseException e){
            e.printStackTrace();
            return null;
        }
    }

    //Set value in race table
    public void resultTableData(String name,Formula1ChampionshipManager x,String[][] resultTableData){
        int i = 0;
        //checks for driver name in races
        for(Race temp : x.getRaces()){
            for(String[] driverTemp : temp.getDriverDetails()){
                if(driverTemp[0] != null){
                    if(driverTemp[0].equals(name)){
                        resultTableData[i][0] = temp.getDate().toString();
                        resultTableData[i][i] = driverTemp[i];
                        break;
                    }
                }
            }
            i++;
        }
    }
}

