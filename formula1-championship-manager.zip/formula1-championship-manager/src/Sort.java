import java.util.Comparator;

public class Sort implements Comparator<Formula1Driver> {
    @Override
    public int compare(Formula1Driver d1, Formula1Driver d2){
        if(d1.getTotalPoints() > d2.getTotalPoints()){
            return -1;
        }
        else{
            if(d1.getTotalPoints() < d2.getTotalPoints()){
                return 1;
            }
            else{
                int d1firstPCount = d1.getFirstPCount();
                int d2firstPCount = d2.getFirstPCount();
                if(d1firstPCount > d2firstPCount){
                    return -1;
                }
                else {
                    if (d1firstPCount < d2firstPCount)
                        return 1;
                    else return 0;
                }

            }
        }
    }
}
