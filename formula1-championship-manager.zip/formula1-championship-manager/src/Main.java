public class Main {
    public static void main(String[] args) {
        Formula1ChampionshipManager formula1ChampionshipManager = new Formula1ChampionshipManager(10);

    }
}
