public class Formula1Driver extends Driver {

    private int firstPCount;
    private int secondPCount;
    private int thirdPCount;
    private int totalPoints;
    private int racesCompleted;

    public int getFirstPCount(){
        return firstPCount;
    }

    public int getSecondPCount() {
        return secondPCount;
    }

    public int getThirdPCount(){
        return thirdPCount;
    }

    public int getTotalPoints() {
        return totalPoints;
    }

    public int getRacesCompleted() {
        return racesCompleted;
    }


    public void setFirstPCount(int i) {
        firstPCount=i;
    }

    public void setSecondPCount(int i){
        secondPCount=i;
    }

    public void setThirdPCount(int i) {
        thirdPCount=i;
    }

    public void setTotalPoints(int i){
        totalPoints=i;
    }

    public void setRacesCompleted(int i){
        racesCompleted=i;
    }

}
