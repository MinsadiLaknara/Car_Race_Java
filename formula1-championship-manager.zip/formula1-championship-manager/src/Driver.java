import java.io.Serializable;

public abstract class Driver implements Serializable{
    private String driverName;
    private String driverLocation;
    private String driverTeam;
    private String driverStats;

    @Override
    public boolean equals(Object o) {return this.driverName.equals(((Driver)o).driverName); }

    public String getDriverName() {
        return driverName;
    }

    public String getDriverLocation() {
        return driverLocation;
    }

    public String getDriverTeam() {
        return driverTeam;
    }

    public String getDriverStats() { return driverStats; }

    public void setDriverName(String s) {
        this.driverName = s;
    }

    public void setDriverLocation(String s) {
        this.driverLocation = s;
    }

    public void setDriverTeam(String s) {
        this.driverTeam = s;
    }

    public void setDriverStats(String s) {
        this.driverStats = s;
    }
}
